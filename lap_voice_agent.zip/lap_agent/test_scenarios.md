# Test calls (do each on the real platform, record each)
1. Happy path: residential, sole owner, originals available, 50 lakh, salaried + bank, value 1.2 crore, 10 years -> handoff
2. Out of order: "I run a shop, income in bank, joint ownership" in first answer -> bot must not re-ask
3. Cash income -> polite disqualification, call ends
4. Agricultural land -> disqualification
5. Asks 1 crore -> limit explained, asks to proceed with 75 lakh (try both yes and no)
6. "I already have a loan on it / want lower EMI" -> transfer message, call ends
7. Busy: "call me later" -> asks callback time, confirms, ends
8. Interrupts, fillers, asks interest rate mid-way -> bot answers briefly, returns to pending question
9. Tenure 20 years -> bot says 3 to 15 allowed
10. No original documents -> disqualification
