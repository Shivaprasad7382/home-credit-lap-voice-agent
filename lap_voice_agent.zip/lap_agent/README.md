# Home Credit LAP Voice Agent
- system_prompt.md : paste this into Retell/Bolna agent instructions (submission item 1)
- variables.json   : test values for the {{variables}} (set the same in the platform)
- simulate.py      : optional local text test (needs Anthropic API key)
- test_scenarios.md: calls to record for submission item 2 (recording + transcript links)
Note: the platform handles conversation_history and customer_utterance itself.
