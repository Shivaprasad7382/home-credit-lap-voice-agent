"""Text simulator for the LAP voice agent.
Usage: pip install anthropic ; export ANTHROPIC_API_KEY=...
       python simulate.py
Type like a customer. Type 'quit' to stop. Transcript saved to transcript.txt
"""
import json, anthropic

MODEL = "claude-sonnet-5-5"
prompt = open("system_prompt.md", encoding="utf-8").read()
vars_ = json.load(open("variables.json", encoding="utf-8"))
client = anthropic.Anthropic()
history = []  # list of (speaker, text)

def render(utterance):
    log = "\n".join(f"{s}: {t}" for s, t in history) or "(call just started)"
    v = dict(vars_, conversation_history=log, customer_utterance=utterance)
    out = prompt
    for k, val in v.items():
        out = out.replace("{{" + k + "}}", val)
    return out

def agent_turn(utterance):
    r = client.messages.create(
        model=MODEL, max_tokens=300,
        system=render(utterance),
        messages=[{"role": "user", "content": utterance or "(call connected, customer picked up)"}],
    )
    return r.content[0].text.strip()

reply = agent_turn("Hello?")
print("AGENT:", reply)
history.append(("Customer", "Hello?"))
history.append(("Agent", reply))
while True:
    u = input("YOU: ").strip()
    if u.lower() in ("quit", "exit"):
        break
    reply = agent_turn(u)
    print("AGENT:", reply)
    history.append(("Customer", u))
    history.append(("Agent", reply))
open("transcript.txt", "w", encoding="utf-8").write("\n".join(f"{s}: {t}" for s, t in history))
